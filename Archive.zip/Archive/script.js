document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const genreSelect = document.getElementById('genre');
    const moodSelect = document.getElementById('mood');
    const tempoSlider = document.getElementById('tempo');
    const tempoValue = document.getElementById('tempo-value');
    const voiceTypeSelect = document.getElementById('voice-type');
    const vocalEffectSelect = document.getElementById('vocal-effect');
    const lyricsTextarea = document.getElementById('lyrics');
    const generateBtn = document.getElementById('generate-btn');
    const playBtn = document.getElementById('play-btn');
    const stopBtn = document.getElementById('stop-btn');
    const downloadBtn = document.getElementById('download-btn');
    const trackTitle = document.getElementById('track-title');
    const trackDetails = document.getElementById('track-details');
    const presetBtns = document.querySelectorAll('.preset-btn');
    const waveform = document.querySelector('.waveform');

    // Mood options for each genre
    const moodOptions = {
        uk_drill: ['Roadman', 'Aggressive', 'Dark', 'Energetic', 'Gritty', 'Menacing'],
        rap: ['Trap', 'Aggressive', 'Melancholic', 'Confident', 'Storytelling', 'Braggadocious'],
        hiphop: ['Chill', 'Old School', 'Jazzy', 'Boom Bap', 'Lyrical', 'Conscious'],
        pop: ['Euphoric', 'Romantic', 'Upbeat', 'Dreamy', 'Dance', 'Summer'],
        rock: ['Angry', 'Rebellious', 'Epic', 'Grunge', 'Psychedelic', 'Alternative'],
        electronic: ['Energetic', 'Chill', 'Dark', 'Melodic', 'Tech', 'House'],
        classical: ['Dramatic', 'Peaceful', 'Romantic', 'Suspenseful', 'Majestic', 'Baroque'],
        trap: ['Dark', 'Hype', 'Atmospheric', 'Bouncy', 'Spacey', 'Aggressive'],
        grime: ['Gritty', 'Energetic', 'Dark', 'Rebellious', 'Street', 'Raw']
    };

    // Default BPM ranges for genres
    const genreBpmRanges = {
        uk_drill: { min: 135, max: 150, default: 140 },
        rap: { min: 70, max: 100, default: 90 },
        hiphop: { min: 80, max: 100, default: 90 },
        pop: { min: 100, max: 130, default: 120 },
        rock: { min: 90, max: 140, default: 120 },
        electronic: { min: 120, max: 140, default: 128 },
        classical: { min: 60, max: 180, default: 90 },
        trap: { min: 130, max: 170, default: 140 },
        grime: { min: 135, max: 145, default: 140 }
    };

    // Current track state
    let currentTrack = null;
    let isPlaying = false;
    let audioContext = null;
    let audioBuffer = null;
    let audioSource = null;

    // Initialize the app
    function init() {
        updateMoodOptions();
        updateTempoForGenre();
        setupEventListeners();
        createWaveform();
    }

    // Set up event listeners
    function setupEventListeners() {
        genreSelect.addEventListener('change', function() {
            updateMoodOptions();
            updateTempoForGenre();
            updateTrackInfo();
        });

        moodSelect.addEventListener('change', updateTrackInfo);
        tempoSlider.addEventListener('input', function() {
            tempoValue.textContent = this.value;
            updateTrackInfo();
        });

        voiceTypeSelect.addEventListener('change', updateTrackInfo);
        vocalEffectSelect.addEventListener('change', updateTrackInfo);
        lyricsTextarea.addEventListener('input', updateTrackInfo);

        generateBtn.addEventListener('click', generateTrack);
        playBtn.addEventListener('click', togglePlayback);
        stopBtn.addEventListener('click', stopPlayback);
        downloadBtn.addEventListener('click', downloadTrack);

        presetBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const bpm = parseInt(this.getAttribute('data-bpm'));
                tempoSlider.value = bpm;
                tempoValue.textContent = bpm;
                updateTrackInfo();
            });
        });
    }

    // Update mood options based on selected genre
    function updateMoodOptions() {
        const selectedGenre = genreSelect.value;
        const moods = moodOptions[selectedGenre];
        
        // Clear existing options
        moodSelect.innerHTML = '';
        
        // Add new options
        moods.forEach(mood => {
            const option = document.createElement('option');
            option.value = mood.toLowerCase();
            option.textContent = mood;
            moodSelect.appendChild(option);
        });
    }

    // Update tempo slider based on genre
    function updateTempoForGenre() {
        const selectedGenre = genreSelect.value;
        const bpmRange = genreBpmRanges[selectedGenre];
        
        tempoSlider.min = bpmRange.min;
        tempoSlider.max = bpmRange.max;
        tempoSlider.value = bpmRange.default;
        tempoValue.textContent = bpmRange.default;
    }

    // Update track info display
    function updateTrackInfo() {
        const genre = genreSelect.options[genreSelect.selectedIndex].text;
        const mood = moodSelect.options[moodSelect.selectedIndex].text;
        const bpm = tempoSlider.value;
        const voiceType = voiceTypeSelect.value === 'none' ? 'Instrumental' : 
                        voiceTypeSelect.options[voiceTypeSelect.selectedIndex].text;
        
        trackTitle.textContent = `${genre} ${mood} Track`;
        trackDetails.textContent = `Genre: ${genre} | Mood: ${mood} | BPM: ${bpm} | Vocals: ${voiceType}`;
    }

    // Create a fake waveform visualization
    function createWaveform() {
        waveform.innerHTML = '';
        
        for (let i = 0; i < 100; i++) {
            const bar = document.createElement('div');
            bar.style.height = `${Math.random() * 80 + 20}px`;
            bar.style.width = '3px';
            bar.style.backgroundColor = var(--primary-color);
            bar.style.position = 'absolute';
            bar.style.bottom = '0';
            bar.style.left = `${i * 4}px`;
            bar.style.transform = 'translateY(-50%)';
            bar.style.borderRadius = '2px';
            waveform.appendChild(bar);
        }
    }

    // Generate track (simulated)
    function generateTrack() {
        // Simulate generation process
        generateBtn.classList.add('generating');
        generateBtn.disabled = true;
        
        // In a real app, this would call an AI music generation API
        setTimeout(() => {
            generateBtn.classList.remove('generating');
            generateBtn.disabled = false;
            
            // Simulate receiving a track
            currentTrack = {
                id: Date.now(),
                title: trackTitle.textContent,
                genre: genreSelect.options[genreSelect.selectedIndex].text,
                mood: moodSelect.options[moodSelect.selectedIndex].text,
                bpm: tempoSlider.value,
                voiceType: voiceTypeSelect.value === 'none' ? 'Instrumental' : 
                         voiceTypeSelect.options[voiceTypeSelect.selectedIndex].text,
                vocalEffect: vocalEffectSelect.value === 'none' ? 'None' : 
                            vocalEffectSelect.options[vocalEffectSelect.selectedIndex].text,
                lyrics: lyricsTextarea.value || 'No lyrics provided',
                audioUrl: '#' // In a real app, this would be the generated audio URL
            };
            
            // Simulate waveform update
            createWaveform();
            
            // Enable playback controls
            playBtn.disabled = false;
            downloadBtn.disabled = false;
            
            // Show success message
            alert('Track generated successfully! Click play to listen.');
        }, 3000);
    }

    // Toggle audio playback
    function togglePlayback() {
        if (!currentTrack) return;
        
        if (!isPlaying) {
            // In a real app, this would play the actual generated audio
            isPlaying = true;
            playBtn.innerHTML = '<i class="fas fa-pause"></i>';
            simulatePlayback();
        } else {
            stopPlayback();
        }
    }

    // Simulate audio playback (visual only)
    function simulatePlayback() {
        if (!isPlaying) return;
        
        const bars = waveform.querySelectorAll('div');
        let currentBar = 0;
        
        const playbackInterval = setInterval(() => {
            if (!isPlaying) {
                clearInterval(playbackInterval);
                return;
            }
            
            // Reset previous bar
            if (currentBar > 0) {
                bars[currentBar - 1].style.backgroundColor = var(--primary-color);
            }
            
            // Highlight current bar
            bars[currentBar].style.backgroundColor = var(--accent-color);
            
            // Move to next bar
            currentBar = (currentBar + 1) % bars.length;
        }, 1000 / (currentTrack.bpm / 60));
    }

    // Stop audio playback
    function stopPlayback() {
        isPlaying = false;
        playBtn.innerHTML = '<i class="fas fa-play"></i>';
        
        // Reset waveform visualization
        const bars = waveform.querySelectorAll('div');
        bars.forEach(bar => {
            bar.style.backgroundColor = var(--primary-color);
        });
    }

    // Download track (simulated)
    function downloadTrack() {
        if (!currentTrack) return;
        
        // In a real app, this would download the actual generated audio file
        alert(`Downloading "${currentTrack.title}"... (This is a simulation)`);
    }

    // Initialize the app
    init();
});